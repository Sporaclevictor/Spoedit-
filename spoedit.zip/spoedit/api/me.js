const { redis, send, fail, uidOk, ipHash, getPrices, getUser, saveUser, isBanned, SERVICES, FREE_PER_IP } = require('../lib/core');

// Returns the visitor's remaining free trials, paid credits, ban status and current prices.
module.exports = async (req, res) => {
  try {
    const id = req.headers['x-uid'];
    if (!uidOk(id)) return send(res, 400, { error: 'bad_uid' });
    const [u, prices] = await Promise.all([getUser(id), getPrices()]);
    u.last = Date.now();
    await saveUser(u);
    const ipUsed = Number(await redis('GET', 'spo:ip:' + ipHash(req))) || 0;
    send(res, 200, {
      free: ipUsed >= FREE_PER_IP ? 0 : u.free,
      credits: u.credits,
      banned: await isBanned(u),
      prices,
      services: SERVICES
    });
  } catch (e) { fail(res, e); }
};
